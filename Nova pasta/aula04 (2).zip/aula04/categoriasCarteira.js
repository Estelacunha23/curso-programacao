let categoria = "E";

switch (categoria) {
    case "A":
        console.log("Moto");
        break;
    
    case "B": 
        console.log("Carro");
        break;
    case "C":
        console.log("Caminhão");
        break;

    case "D": 
        console.log("Onibus");
        break;

    default: 
        console.log("Categoria Indefinida");
    
}
