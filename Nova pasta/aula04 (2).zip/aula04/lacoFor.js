// inicio => VALOR INICIAL
// condicao => ATÉ ONDE O LAÇO VAI?
// incremento ou decremento => De quanto em quanto ele vai?
let num = 3;

for(let i = 0; i <= 100; i++) {
    console.log(num + " x " + i + " = " + num * i);
}