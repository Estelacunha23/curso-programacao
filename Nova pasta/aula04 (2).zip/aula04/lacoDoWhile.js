let resposta = "SIM"

do {
    console.log("VOCÊ DIGITOU " + resposta);
}
while(resposta === "não");