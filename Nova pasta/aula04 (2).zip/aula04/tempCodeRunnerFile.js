
    console.log(num + " x " + i + " 