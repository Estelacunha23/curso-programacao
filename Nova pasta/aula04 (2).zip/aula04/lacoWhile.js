// let i = 0;
// while(i <= 10) {

//     i++;
// }

let resposta = "SIM"

while(resposta === "não") {
    console.log("VOCÊ DIGITOU " + resposta);
}
