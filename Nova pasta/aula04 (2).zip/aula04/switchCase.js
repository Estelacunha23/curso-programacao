let numero = 25;

switch(numero) {
    case 1:
        console.log("Numero 1 digitado com sucesso");
        break;
    case 2:
        console.log("Numero 2 digitado com sucesso");
        break;
    case 3: 
        console.log("Numero 3 digitado com sucesso");
        break;

    default:
        console.log("Outro numero foi digitado");
}