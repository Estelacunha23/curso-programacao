let nota = 0.5;
let situacao;

// if (nota >= 7) {
//     console.log("APROVADO");
// } else {
//     if (nota < 7 && nota >= 5) {
//         console.log("RECUPERAÇÃO");
//     } else {
//         console.log("REPROVADO");
//     }
// }

// if (nota >= 7) {
//     console.log("APROVADO");
// } else if (nota < 7 && nota >= 5) {
//     console.log("RECUPERAÇÃO");
// } else if (nota < 5 && nota >=2 ) {
//     console.log("REPROVADO");
// } else {
//     console.log("Que burro da zero pra ele");
// }

if (nota >= 7) {
    console.log("APROVADO");
} else if (nota < 5) {
    console.log("REPROVADO");
} else {
    console.log("RECUPERAÇÃO");
}